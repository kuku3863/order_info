#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import User

app = create_app('default')
app.app_context().push()

admin = User.query.filter_by(username='admin').first()
print(f'管理员存在: {admin is not None}')
if admin:
    print(f'管理员ID: {admin.id}')
    print(f'管理员角色: {admin.role}')
    print(f'管理员用户名: {admin.username}')
else:
    print('需要创建管理员账户')
    # 创建管理员账户
    from werkzeug.security import generate_password_hash
    from app.models import Role
    admin_role = Role.query.filter_by(name='SuperAdmin').first()
    if not admin_role:
        Role.insert_roles()
        admin_role = Role.query.filter_by(name='SuperAdmin').first()
    
    admin = User(
        username='admin',
        email='admin@example.com',
        password_hash=generate_password_hash('admin123'),
        role=admin_role
    )
    db.session.add(admin)
    db.session.commit()
    print('管理员账户已创建')