#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import Order, WechatUser
from flask import render_template_string

def debug_template_logic():
    """调试模板逻辑"""
    app = create_app('default')
    
    with app.app_context():
        # 计算uncollected_count（复制自views.py的逻辑）
        unique_phones_in_orders = db.session.query(Order.phone).filter(
            Order.phone.isnot(None),
            Order.phone != ''
        ).distinct().all()
        unique_phones_in_orders = [phone[0] for phone in unique_phones_in_orders]
        
        existing_phones = db.session.query(WechatUser.phone).filter(
            WechatUser.phone.isnot(None)
        ).all()
        existing_phones = [phone[0] for phone in existing_phones]
        
        uncollected_phones = set(unique_phones_in_orders) - set(existing_phones)
        uncollected_count = len(uncollected_phones)
        
        print(f"订单中的唯一手机号: {unique_phones_in_orders}")
        print(f"已存在的微信用户手机号: {existing_phones}")
        print(f"可收集的手机号: {list(uncollected_phones)}")
        print(f"uncollected_count: {uncollected_count}")
        
        # 测试模板条件
        template_test = """
        {% if uncollected_count > 0 %}
        收集按钮应该显示: uncollected_count = {{ uncollected_count }}
        {% else %}
        收集按钮不显示: uncollected_count = {{ uncollected_count }}
        {% endif %}
        """
        
        result = render_template_string(template_test, uncollected_count=uncollected_count)
        print(f"模板测试结果: {result.strip()}")
        
        # 检查微信用户数据
        wechat_users = WechatUser.query.all()
        print(f"\n当前微信用户数量: {len(wechat_users)}")
        for user in wechat_users:
            print(f"  - {user.wechat_name}, 手机号: {user.phone}")

if __name__ == '__main__':
    print("=== 调试模板逻辑 ===")
    debug_template_logic()