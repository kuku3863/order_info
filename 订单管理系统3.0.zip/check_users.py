#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import User, Role, Permission

def check_users_and_roles():
    """检查用户和角色设置"""
    app = create_app('default')
    
    with app.app_context():
        # 检查所有角色
        roles = Role.query.all()
        print("=== 角色列表 ===")
        for role in roles:
            print(f"角色: {role.name}, 权限: {role.permissions}, 默认: {role.default}")
            print(f"  - 查看自己订单: {role.has_permission(Permission.VIEW_OWN)}")
            print(f"  - 提交订单: {role.has_permission(Permission.SUBMIT)}")
            print(f"  - 查看所有订单: {role.has_permission(Permission.VIEW_ALL)}")
            print(f"  - 管理字段: {role.has_permission(Permission.MANAGE_FIELDS)}")
            print(f"  - 管理员权限: {role.has_permission(Permission.ADMIN)}")
            print()
        
        # 检查所有用户
        users = User.query.all()
        print("=== 用户列表 ===")
        for user in users:
            print(f"用户: {user.username}, 邮箱: {user.email}")
            if user.role:
                print(f"  角色: {user.role.name}")
                print(f"  是否管理员: {user.is_administrator()}")
                print(f"  管理员权限: {user.can(Permission.ADMIN)}")
            else:
                print(f"  角色: 无")
            print()
        
        # 检查是否有管理员用户
        admin_users = []
        for user in users:
            if user.can(Permission.ADMIN):
                admin_users.append(user)
        
        print(f"管理员用户数量: {len(admin_users)}")
        for admin in admin_users:
            print(f"  - {admin.username} ({admin.email})")

if __name__ == '__main__':
    check_users_and_roles()