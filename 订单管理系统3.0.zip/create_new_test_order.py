from app import create_app, db
from app.models import Order, OrderType
from datetime import datetime

def create_new_test_order():
    app = create_app('default')
    with app.app_context():
        # 获取第一个订单类型
        order_type = OrderType.query.first()
        if not order_type:
            print("未找到订单类型")
            return
        
        # 创建一个新的测试订单，使用新的手机号
        new_order = Order(
            order_code=f'TEST{datetime.now().strftime("%Y%m%d%H%M%S")}',
            wechat_name='测试用户',
            wechat_id='test_user_123',
            phone='13999999999',  # 新的手机号
            order_info='测试订单信息',
            completion_time=datetime.now().date(),
            quantity=1,
            amount=100.0,
            order_type_id=order_type.id,
            user_id=1  # 假设admin用户ID为1
        )
        
        try:
            db.session.add(new_order)
            db.session.commit()
            print(f"成功创建测试订单: {new_order.order_code}")
            print(f"微信名: {new_order.wechat_name}")
            print(f"手机号: {new_order.phone}")
            
            # 检查uncollected_count
            from app.models import WechatUser
            
            # 获取所有有手机号的订单
            orders_with_phone = Order.query.filter(Order.phone.isnot(None), Order.phone != '').all()
            order_phones = set(order.phone for order in orders_with_phone)
            
            # 获取已收集的微信用户手机号
            wechat_users = WechatUser.query.all()
            collected_phones = set(user.phone for user in wechat_users if user.phone)
            
            # 计算未收集的手机号
            uncollected_phones = order_phones - collected_phones
            uncollected_count = len(uncollected_phones)
            
            print(f"\n当前uncollected_count: {uncollected_count}")
            if uncollected_count > 0:
                print(f"未收集的手机号: {uncollected_phones}")
                print("现在应该能看到收集按钮了")
            else:
                print("所有用户都已收集")
                
        except Exception as e:
            print(f"创建订单失败: {e}")
            db.session.rollback()

if __name__ == '__main__':
    create_new_test_order()