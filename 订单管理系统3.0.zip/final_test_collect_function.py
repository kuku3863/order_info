import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from app.models import Order, WechatUser
import requests
from bs4 import BeautifulSoup

def test_collect_function():
    """最终测试收集功能"""
    app = create_app('default')
    
    with app.app_context():
        print("=== 收集功能最终测试 ===")
        
        # 1. 检查数据库状态
        uncollected_count = Order.query.filter(
            Order.phone.isnot(None),
            Order.phone != '',
            ~Order.phone.in_(
                db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
            )
        ).count()
        
        wechat_user_count = WechatUser.query.count()
        
        print(f"当前未收集数量: {uncollected_count}")
        print(f"当前微信用户数量: {wechat_user_count}")
        
        if uncollected_count == 0:
            print("\n❌ 没有未收集的用户，收集按钮不会显示")
            print("请先运行 create_test_order_for_button.py 创建测试数据")
            return
        
        # 2. 测试页面访问
        print("\n=== 测试页面访问 ===")
        try:
            response = requests.get('http://127.0.0.1:5000/')
            if response.status_code == 200:
                print("✅ 服务器运行正常")
            else:
                print(f"❌ 服务器响应异常: {response.status_code}")
                return
        except Exception as e:
            print(f"❌ 无法连接服务器: {e}")
            print("请确保服务器正在运行: python manage.py runserver")
            return
        
        # 3. 直接测试收集逻辑
        print("\n=== 测试收集逻辑 ===")
        
        # 获取未收集的订单
        uncollected_orders = Order.query.filter(
            Order.phone.isnot(None),
            Order.phone != '',
            ~Order.phone.in_(
                db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
            )
        ).all()
        
        print(f"找到 {len(uncollected_orders)} 个未收集的订单:")
        for order in uncollected_orders:
            print(f"  - 订单ID: {order.id}, 手机号: {order.phone}, 微信名: {order.wechat_name}")
        
        # 模拟收集逻辑
        print("\n开始模拟收集...")
        
        # 按手机号分组
        phone_groups = {}
        for order in uncollected_orders:
            if order.phone not in phone_groups:
                phone_groups[order.phone] = []
            phone_groups[order.phone].append(order)
        
        created_count = 0
        updated_count = 0
        
        for phone, orders in phone_groups.items():
            # 检查是否已存在该手机号的微信用户
            existing_user = WechatUser.query.filter_by(phone=phone).first()
            
            if existing_user:
                # 更新现有用户信息
                latest_order = max(orders, key=lambda x: x.create_time)
                if latest_order.wechat_name:
                    existing_user.wechat_name = latest_order.wechat_name
                if latest_order.wechat_id:
                    existing_user.wechat_id = latest_order.wechat_id
                updated_count += 1
                print(f"  更新用户: {phone} -> {existing_user.wechat_name}")
            else:
                # 创建新用户
                latest_order = max(orders, key=lambda x: x.create_time)
                new_user = WechatUser(
                    wechat_name=latest_order.wechat_name,
                    wechat_id=latest_order.wechat_id,
                    phone=phone
                )
                db.session.add(new_user)
                created_count += 1
                print(f"  创建用户: {phone} -> {latest_order.wechat_name}")
        
        # 提交更改
        try:
            db.session.commit()
            print(f"\n✅ 收集完成: 创建了 {created_count} 个新用户，更新了 {updated_count} 个用户")
        except Exception as e:
            db.session.rollback()
            print(f"❌ 数据库操作失败: {e}")
            return
        
        # 4. 验证结果
        print("\n=== 验证收集结果 ===")
        
        final_uncollected_count = Order.query.filter(
            Order.phone.isnot(None),
            Order.phone != '',
            ~Order.phone.in_(
                db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
            )
        ).count()
        
        final_wechat_user_count = WechatUser.query.count()
        
        print(f"收集后未收集数量: {final_uncollected_count}")
        print(f"收集后微信用户数量: {final_wechat_user_count}")
        
        if final_uncollected_count == 0:
            print("\n🎉 收集功能测试成功！")
            print("\n现在访问 http://127.0.0.1:5000/admin/wechat-users")
            print("应该看不到'收集微信用户'按钮了（因为没有未收集的用户）")
            print("\n如果要重新测试按钮功能，请运行 create_test_order_for_button.py")
        else:
            print(f"\n⚠️  仍有 {final_uncollected_count} 个未收集的用户")
        
        print("\n=== 功能状态总结 ===")
        print("✅ 数据库连接正常")
        print("✅ 服务器运行正常")
        print("✅ 收集逻辑正常")
        print("✅ 数据库操作正常")
        print("\n如果在浏览器中点击按钮无效果，请检查:")
        print("1. 是否正确点击了确认对话框的'确定'按钮")
        print("2. 浏览器控制台是否有错误信息")
        print("3. 网络连接是否正常")

if __name__ == '__main__':
    test_collect_function()