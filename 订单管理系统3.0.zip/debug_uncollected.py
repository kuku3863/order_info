#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import Order, WechatUser

app = create_app('default')
app.app_context().push()

# 检查uncollected_count的计算逻辑
print("=== 调试uncollected_count计算 ===")

# 1. 获取所有有手机号的订单
orders_with_phone = Order.query.filter(
    Order.phone.isnot(None),
    Order.phone != ''
).all()

print(f"有手机号的订单数量: {len(orders_with_phone)}")
for order in orders_with_phone:
    print(f"  订单ID: {order.id}, 手机号: {order.phone}, 微信名: {order.wechat_name}")

# 2. 获取所有微信用户的手机号
wechat_user_phones = db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None)).all()
wechat_user_phones = [phone[0] for phone in wechat_user_phones if phone[0]]

print(f"\n微信用户的手机号: {wechat_user_phones}")

# 3. 计算uncollected_count（原始逻辑）
uncollected_count_original = Order.query.filter(
    Order.phone.isnot(None),
    Order.phone != '',
    ~Order.phone.in_(
        db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
    )
).count()

print(f"\n原始uncollected_count: {uncollected_count_original}")

# 4. 手动计算uncollected_count
uncollected_phones = set()
for order in orders_with_phone:
    if order.phone not in wechat_user_phones:
        uncollected_phones.add(order.phone)

print(f"手动计算的未收集手机号: {uncollected_phones}")
print(f"手动计算的uncollected_count: {len(uncollected_phones)}")

# 5. 检查具体的未收集订单
if uncollected_phones:
    print("\n未收集的订单详情:")
    for phone in uncollected_phones:
        orders = Order.query.filter_by(phone=phone).all()
        print(f"  手机号 {phone}:")
        for order in orders:
            print(f"    订单ID: {order.id}, 微信名: {order.wechat_name}, 微信号: {order.wechat_id}")
else:
    print("\n没有未收集的订单")

# 6. 检查是否有空字符串的手机号
empty_phone_orders = Order.query.filter(
    db.or_(
        Order.phone == '',
        Order.phone.is_(None)
    )
).all()

print(f"\n手机号为空的订单数量: {len(empty_phone_orders)}")

print("\n=== 调试完成 ===")