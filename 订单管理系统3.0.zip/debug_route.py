#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import Order, WechatUser, User, Role
from flask import url_for

app = create_app('default')

with app.app_context():
    print("=== 调试路由和模板渲染 ===")
    
    # 1. 直接计算uncollected_count
    print("\n1. 直接计算uncollected_count:")
    uncollected_count = Order.query.filter(
        Order.phone.isnot(None),
        Order.phone != '',
        ~Order.phone.in_(
            db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
        )
    ).count()
    print(f"   uncollected_count = {uncollected_count}")
    
    # 2. 模拟登录并访问路由
    print("\n2. 模拟登录并访问路由:")
    with app.test_client() as client:
        # 获取管理员用户
        admin_role = Role.query.filter_by(name='SuperAdmin').first()
        if not admin_role:
            admin_role = Role.query.filter_by(name='Admin').first()
        if admin_role:
            admin_user = User.query.filter_by(role_id=admin_role.id).first()
            if admin_user:
                print(f"   找到管理员用户: {admin_user.username}")
                
                # 模拟登录 - 使用Flask-Login的方式
                from flask_login import login_user
                with app.test_request_context():
                    login_user(admin_user)
                
                # 访问微信用户页面
                response = client.get('/admin/wechat-users')
                print(f"   GET /admin/wechat-users 状态码: {response.status_code}")
                
                if response.status_code == 200:
                    response_text = response.get_data(as_text=True)
                    
                    # 检查关键内容
                    if 'uncollected_count' in response_text:
                        print("   ✓ 响应包含uncollected_count变量")
                    else:
                        print("   ✗ 响应不包含uncollected_count变量")
                        
                    if '收集微信用户' in response_text:
                        print("   ✓ 响应包含'收集微信用户'文本")
                        # 查找具体的按钮
                        if 'id="collectBtn"' in response_text:
                            print("   ✓ 响应包含收集按钮")
                        else:
                            print("   ✗ 响应不包含收集按钮")
                    else:
                        print("   ✗ 响应不包含'收集微信用户'文本")
                        
                    # 检查条件判断
                    if 'uncollected_count > 0' in response_text:
                        print("   ✓ 响应包含条件判断")
                    else:
                        print("   ✗ 响应不包含条件判断")
                        
                    # 查找模板中的关键行
                    print("\n   查找相关模板内容:")
                    lines = response_text.split('\n')
                    found_relevant = False
                    for i, line in enumerate(lines):
                        if 'uncollected_count' in line or '收集微信用户' in line:
                            print(f"     行{i+1}: {line.strip()}")
                            found_relevant = True
                    
                    if not found_relevant:
                        print("     未找到相关内容")
                        
                    # 检查是否有JavaScript错误
                    if 'handleCollectSubmit' in response_text:
                        print("   ✓ 响应包含handleCollectSubmit函数")
                    else:
                        print("   ✗ 响应不包含handleCollectSubmit函数")
                        
                else:
                    print(f"   请求失败: {response.status_code}")
                    if response.status_code == 302:
                        print(f"   重定向到: {response.headers.get('Location')}")
            else:
                print("   未找到管理员用户")
        else:
            print("   未找到管理员角色")
            
print("\n=== 调试完成 ===")