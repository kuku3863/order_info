#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
调试刷新按钮问题的脚本
"""

import os
import sys
import requests
from bs4 import BeautifulSoup

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from app.models import WechatUser, Order

def debug_refresh_button():
    """调试刷新按钮问题"""
    app = create_app('development')
    
    with app.app_context():
        print("=== 刷新按钮问题调试 ===")
        
        # 1. 检查数据库状态
        print("\n1. 检查当前数据库状态:")
        wechat_users = WechatUser.query.all()
        orders = Order.query.all()
        print(f"   微信用户数量: {len(wechat_users)}")
        print(f"   订单数量: {len(orders)}")
        
        # 2. 测试服务器连接
        print("\n2. 测试服务器连接:")
        base_url = 'http://127.0.0.1:5000'
        
        try:
            # 创建会话
            session = requests.Session()
            
            # 访问微信用户列表页面
            print("   访问微信用户列表页面...")
            response = session.get(f'{base_url}/admin/wechat-users')
            print(f"   状态码: {response.status_code}")
            
            if response.status_code == 200:
                print("   ✓ 页面访问成功")
                
                # 解析页面，查找CSRF token
                soup = BeautifulSoup(response.text, 'html.parser')
                csrf_input = soup.find('input', {'name': 'csrf_token'})
                
                if csrf_input:
                    csrf_token = csrf_input.get('value')
                    print(f"   ✓ 找到CSRF token: {csrf_token[:20]}...")
                    
                    # 查找刷新按钮
                    refresh_form = soup.find('form', {'id': 'refreshForm'})
                    if refresh_form:
                        print("   ✓ 找到刷新表单")
                        action = refresh_form.get('action')
                        print(f"   表单action: {action}")
                        
                        # 3. 模拟刷新按钮点击
                        print("\n3. 模拟刷新按钮点击:")
                        refresh_data = {
                            'csrf_token': csrf_token
                        }
                        
                        print("   发送刷新请求...")
                        refresh_response = session.post(f'{base_url}/admin/refresh-wechat-users', 
                                                       data=refresh_data, 
                                                       allow_redirects=False)
                        
                        print(f"   刷新请求状态码: {refresh_response.status_code}")
                        
                        if refresh_response.status_code == 302:
                            print("   ✓ 刷新请求成功，页面重定向")
                            redirect_url = refresh_response.headers.get('Location', '')
                            print(f"   重定向到: {redirect_url}")
                            
                            # 跟随重定向
                            print("   跟随重定向...")
                            final_response = session.get(f'{base_url}{redirect_url}')
                            print(f"   最终页面状态码: {final_response.status_code}")
                            
                            # 检查是否有成功消息
                            if '成功刷新' in final_response.text:
                                print("   ✓ 发现成功消息")
                            elif '出错' in final_response.text:
                                print("   ✗ 发现错误消息")
                            else:
                                print("   ? 未发现明确的结果消息")
                                
                        elif refresh_response.status_code == 200:
                            print("   ✓ 刷新请求处理完成")
                            if '成功刷新' in refresh_response.text:
                                print("   结果: 刷新成功")
                            elif '出错' in refresh_response.text:
                                print("   结果: 刷新出错")
                        else:
                            print(f"   ✗ 刷新请求失败: {refresh_response.status_code}")
                            print(f"   响应内容: {refresh_response.text[:500]}")
                            
                    else:
                        print("   ✗ 未找到刷新表单")
                        
                else:
                    print("   ✗ 未找到CSRF token")
                    
            else:
                print(f"   ✗ 页面访问失败: {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            print("   ✗ 无法连接到服务器")
            print("   请确保服务器正在运行: python manage.py runserver")
        except Exception as e:
            print(f"   ✗ 请求出错: {str(e)}")
        
        # 4. 直接测试刷新逻辑
        print("\n4. 直接测试刷新逻辑:")
        try:
            from app.admin.views import refresh_wechat_users
            
            print("   执行刷新逻辑...")
            
            # 获取刷新前的状态
            before_count = WechatUser.query.count()
            print(f"   刷新前微信用户数量: {before_count}")
            
            # 模拟刷新逻辑（不通过HTTP请求）
            wechat_users = WechatUser.query.all()
            updated_count = 0
            cleaned_count = 0
            
            for wechat_user in wechat_users:
                # 检查是否为无效用户
                if (not wechat_user.phone or not wechat_user.phone.strip()) and \
                   (not wechat_user.wechat_id or not wechat_user.wechat_id.strip()):
                    print(f"   发现无效用户: {wechat_user.wechat_name}")
                    cleaned_count += 1
                    continue
                
                # 根据手机号查找最新订单
                if wechat_user.phone and wechat_user.phone.strip():
                    latest_order = Order.query.filter_by(phone=wechat_user.phone).order_by(Order.create_time.desc()).first()
                    
                    if latest_order:
                        updated = False
                        # 检查是否需要更新
                        if latest_order.wechat_name and latest_order.wechat_name != wechat_user.wechat_name:
                            print(f"   用户 {wechat_user.wechat_name} 的微信名可以更新为: {latest_order.wechat_name}")
                            updated = True
                        if latest_order.wechat_id and (not wechat_user.wechat_id or not wechat_user.wechat_id.strip()):
                            print(f"   用户 {wechat_user.wechat_name} 的微信号可以更新为: {latest_order.wechat_id}")
                            updated = True
                        
                        if updated:
                            updated_count += 1
            
            print(f"   可以更新的用户数量: {updated_count}")
            print(f"   可以清理的无效用户数量: {cleaned_count}")
            
        except Exception as e:
            print(f"   ✗ 直接测试刷新逻辑出错: {str(e)}")
        
        print("\n=== 调试完成 ===")
        print("\n建议检查项:")
        print("1. 确保服务器正在运行")
        print("2. 检查浏览器控制台是否有JavaScript错误")
        print("3. 检查网络请求是否被阻止")
        print("4. 尝试清除浏览器缓存")

if __name__ == '__main__':
    debug_refresh_button()