import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from app.models import Order, OrderType, WechatUser
from datetime import datetime

def create_test_order():
    """创建一个新的测试订单用于测试收集按钮"""
    app = create_app('default')
    
    with app.app_context():
        print("=== 创建测试订单 ===")
        
        # 获取第一个订单类型
        order_type = OrderType.query.first()
        if not order_type:
            print("没有找到订单类型")
            return
        
        # 创建一个新的测试订单，使用一个新的手机号
        test_phone = "13888888888"
        test_wechat_name = "测试收集按钮用户"
        
        # 检查是否已存在该手机号的订单
        existing_order = Order.query.filter_by(phone=test_phone).first()
        if existing_order:
            print(f"手机号 {test_phone} 的订单已存在")
        else:
            # 创建新订单
            new_order = Order(
                order_code=f"TEST{datetime.now().strftime('%Y%m%d%H%M%S')}",
                wechat_name=test_wechat_name,
                phone=test_phone,
                order_type_id=order_type.id,
                create_time=datetime.utcnow()
            )
            
            db.session.add(new_order)
            db.session.commit()
            
            print(f"✓ 创建了测试订单: {new_order.order_code}")
            print(f"  微信名: {test_wechat_name}")
            print(f"  手机号: {test_phone}")
        
        # 检查当前的uncollected_count
        uncollected_count = Order.query.filter(
            Order.phone.isnot(None),
            Order.phone != '',
            ~Order.phone.in_(
                db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
            )
        ).count()
        
        print(f"\n当前uncollected_count: {uncollected_count}")
        
        if uncollected_count > 0:
            # 显示未收集的订单
            uncollected_orders = Order.query.filter(
                Order.phone.isnot(None),
                Order.phone != '',
                ~Order.phone.in_(
                    db.session.query(WechatUser.phone).filter(WechatUser.phone.isnot(None))
                )
            ).all()
            
            print("未收集的订单:")
            for order in uncollected_orders:
                print(f"  订单ID: {order.id}, 手机号: {order.phone}, 微信名: {order.wechat_name}")
            
            print(f"\n现在应该能在页面上看到'收集微信用户 ({uncollected_count})'按钮了！")
        else:
            print("所有订单都已收集，按钮不会显示")

if __name__ == '__main__':
    create_test_order()