#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
创建测试订单数据
"""

import os
import sys
from datetime import datetime, timedelta
import random
import uuid

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app, db
from app.models import Order, OrderType, User

def generate_order_code():
    """生成唯一的订单编码"""
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
    random_num = random.randint(1000, 9999)
    return f'ORD{timestamp}{random_num}'

def create_test_orders():
    """创建测试订单数据"""
    app = create_app('development')
    
    with app.app_context():
        print("开始创建测试订单数据...")
        
        # 获取管理员用户
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            print("错误：未找到管理员用户")
            return
        
        # 获取订单类型
        order_types = OrderType.query.all()
        if not order_types:
            print("错误：未找到订单类型")
            return
        
        # 测试数据
        test_orders = [
            {
                'wechat_name': '张三',
                'wechat_id': 'zhangsan123',
                'phone': '13800138001',
                'product_name': 'iPhone 15 Pro',
                'quantity': 1,
                'unit_price': 8999.00,
                'total_amount': 8999.00,
                'notes': '黑色256GB版本'
            },
            {
                'wechat_name': '李四',
                'wechat_id': 'lisi456',
                'phone': '13800138002',
                'product_name': 'MacBook Air M3',
                'quantity': 1,
                'unit_price': 9499.00,
                'total_amount': 9499.00,
                'notes': '13寸银色版本'
            },
            {
                'wechat_name': '王五',
                'wechat_id': 'wangwu789',
                'phone': '13800138003',
                'product_name': 'AirPods Pro 2',
                'quantity': 2,
                'unit_price': 1899.00,
                'total_amount': 3798.00,
                'notes': '白色版本，买二送一活动'
            },
            {
                'wechat_name': '赵六',
                'wechat_id': 'zhaoliu101',
                'phone': '13800138004',
                'product_name': 'iPad Pro 12.9',
                'quantity': 1,
                'unit_price': 7999.00,
                'total_amount': 7999.00,
                'notes': '512GB WiFi版本'
            },
            {
                'wechat_name': '孙七',
                'wechat_id': 'sunqi202',
                'phone': '13800138005',
                'product_name': 'Apple Watch Ultra 2',
                'quantity': 1,
                'unit_price': 6299.00,
                'total_amount': 6299.00,
                'notes': '钛金属表壳，橙色运动表带'
            }
        ]
        
        created_count = 0
        
        for i, order_data in enumerate(test_orders):
            try:
                # 随机选择订单类型
                order_type = random.choice(order_types)
                
                # 创建订单时间（最近7天内的随机时间）
                days_ago = random.randint(0, 7)
                hours_ago = random.randint(0, 23)
                minutes_ago = random.randint(0, 59)
                create_time = datetime.now() - timedelta(days=days_ago, hours=hours_ago, minutes=minutes_ago)
                
                # 生成唯一的订单编码
                order_code = generate_order_code()
                
                # 创建订单
                order = Order(
                    order_code=order_code,
                    wechat_name=order_data['wechat_name'],
                    wechat_id=order_data['wechat_id'],
                    phone=order_data['phone'],
                    order_info=order_data['product_name'],  # 使用order_info字段存储产品信息
                    quantity=order_data['quantity'],
                    amount=order_data['total_amount'],  # 使用amount字段而不是total_amount
                    notes=order_data['notes'],
                    order_type_id=order_type.id,
                    user_id=admin_user.id,
                    create_time=create_time
                )
                
                db.session.add(order)
                created_count += 1
                print(f"✓ 创建订单 {i+1}: {order_data['wechat_name']} - {order_data['product_name']}")
                
            except Exception as e:
                print(f"✗ 创建订单 {i+1} 失败: {str(e)}")
        
        try:
            db.session.commit()
            print(f"\n✅ 成功创建了 {created_count} 个测试订单")
            
            # 显示当前订单总数
            total_orders = Order.query.count()
            print(f"📊 数据库中总订单数: {total_orders}")
            
        except Exception as e:
            db.session.rollback()
            print(f"✗ 提交数据库时出错: {str(e)}")

if __name__ == '__main__':
    create_test_orders()