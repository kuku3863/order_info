#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import User, Role

app = create_app('default')
app.app_context().push()

print("=== 检查角色和用户 ===")

# 检查所有角色
roles = Role.query.all()
print(f"\n数据库中的角色数量: {len(roles)}")
for role in roles:
    print(f"  角色ID: {role.id}, 名称: {role.name}")

# 检查所有用户
users = User.query.all()
print(f"\n数据库中的用户数量: {len(users)}")
for user in users:
    role_name = user.role.name if user.role else '无角色'
    print(f"  用户ID: {user.id}, 用户名: {user.username}, 邮箱: {user.email}, 角色: {role_name}")

# 查找管理员
admin_role = Role.query.filter_by(name='Administrator').first()
if admin_role:
    print(f"\n找到Administrator角色: ID={admin_role.id}")
    admin_users = User.query.filter_by(role_id=admin_role.id).all()
    print(f"Administrator角色的用户数量: {len(admin_users)}")
    for user in admin_users:
        print(f"  管理员用户: {user.username} ({user.email})")
else:
    print("\n未找到Administrator角色")
    
    # 尝试查找其他可能的管理员角色名
    possible_names = ['Admin', 'admin', 'administrator', '管理员']
    for name in possible_names:
        role = Role.query.filter_by(name=name).first()
        if role:
            print(f"找到角色: {name} (ID={role.id})")
            users = User.query.filter_by(role_id=role.id).all()
            for user in users:
                print(f"  用户: {user.username} ({user.email})")

print("\n=== 检查完成 ===")