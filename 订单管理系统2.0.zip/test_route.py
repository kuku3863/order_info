#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
from app import create_app, db
from app.models import Order, WechatUser
from flask import url_for

def test_route_directly():
    """直接测试路由函数"""
    app = create_app('default')
    
    with app.app_context():
        with app.test_client() as client:
            # 模拟登录（需要管理员权限）
            # 这里我们直接测试路由逻辑
            
            # 计算uncollected_count
            unique_phones_in_orders = db.session.query(Order.phone).filter(
                Order.phone.isnot(None),
                Order.phone != ''
            ).distinct().all()
            unique_phones_in_orders = [phone[0] for phone in unique_phones_in_orders]
            
            existing_phones = db.session.query(WechatUser.phone).filter(
                WechatUser.phone.isnot(None)
            ).all()
            existing_phones = [phone[0] for phone in existing_phones]
            
            uncollected_phones = set(unique_phones_in_orders) - set(existing_phones)
            uncollected_count = len(uncollected_phones)
            
            print(f"订单中的唯一手机号: {unique_phones_in_orders}")
            print(f"已存在的微信用户手机号: {existing_phones}")
            print(f"可收集的手机号: {list(uncollected_phones)}")
            print(f"uncollected_count: {uncollected_count}")
            
            # 测试URL生成
            try:
                wechat_user_list_url = url_for('admin.wechat_user_list')
                collect_url = url_for('admin.collect_wechat_users')
                print(f"微信用户列表URL: {wechat_user_list_url}")
                print(f"收集用户URL: {collect_url}")
            except Exception as e:
                print(f"URL生成错误: {e}")

if __name__ == '__main__':
    print("=== 测试路由逻辑 ===")
    test_route_directly()