#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
from requests.sessions import Session

def test_with_login():
    """测试登录后访问微信用户页面"""
    session = Session()
    
    try:
        # 1. 先访问登录页面获取CSRF token
        login_page = session.get('http://127.0.0.1:5000/auth/login')
        print(f"登录页面状态码: {login_page.status_code}")
        
        # 2. 尝试访问微信用户页面（未登录）
        wechat_page = session.get('http://127.0.0.1:5000/admin/wechat-users')
        print(f"未登录访问微信用户页面状态码: {wechat_page.status_code}")
        
        if wechat_page.status_code == 302:
            print("页面重定向到登录页面（需要登录）")
        elif wechat_page.status_code == 403:
            print("访问被拒绝（需要管理员权限）")
        elif wechat_page.status_code == 200:
            print("可以直接访问（无需登录）")
            if '收集微信用户' in wechat_page.text:
                print("页面包含收集按钮")
            else:
                print("页面不包含收集按钮")
                # 检查uncollected_count
                if 'uncollected_count' in wechat_page.text:
                    print("页面包含uncollected_count变量")
                else:
                    print("页面不包含uncollected_count变量")
        
        # 3. 检查页面内容
        print(f"页面内容长度: {len(wechat_page.text)}")
        
        # 查找关键词
        keywords = ['微信用户管理', 'uncollected_count', '收集微信用户', 'admin.collect_wechat_users']
        for keyword in keywords:
            if keyword in wechat_page.text:
                print(f"找到关键词: {keyword}")
            else:
                print(f"未找到关键词: {keyword}")
                
    except requests.exceptions.RequestException as e:
        print(f"请求失败: {e}")

if __name__ == '__main__':
    print("=== 测试登录和权限 ===")
    test_with_login()