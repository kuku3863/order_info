#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import re
from requests.sessions import Session

def test_collect_post():
    """测试直接POST到收集微信用户接口"""
    session = Session()
    
    try:
        # 1. 登录
        login_page = session.get('http://127.0.0.1:5000/auth/login')
        csrf_match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', login_page.text)
        csrf_token = csrf_match.group(1) if csrf_match else None
        
        login_data = {
            'account': 'admin@example.com',
            'password': 'admin123',
            'remember_me': False
        }
        if csrf_token:
            login_data['csrf_token'] = csrf_token
        
        login_response = session.post('http://127.0.0.1:5000/auth/login', data=login_data)
        print(f"登录状态码: {login_response.status_code}")
        
        # 2. 直接POST到收集接口
        collect_response = session.post('http://127.0.0.1:5000/admin/collect-wechat-users')
        print(f"收集接口状态码: {collect_response.status_code}")
        
        if collect_response.status_code == 302:
            print("收集成功，页面重定向")
            print(f"重定向到: {collect_response.headers.get('Location', '未知')}")
        elif collect_response.status_code == 200:
            print("收集请求处理完成")
            if '成功收集' in collect_response.text:
                print("✓ 收集成功")
            elif '出错' in collect_response.text:
                print("✗ 收集出错")
        else:
            print(f"收集失败，状态码: {collect_response.status_code}")
            print(f"响应内容: {collect_response.text[:200]}")
        
        # 3. 再次访问微信用户页面检查结果
        wechat_page = session.get('http://127.0.0.1:5000/admin/wechat-users')
        print(f"\n微信用户页面状态码: {wechat_page.status_code}")
        
        if '暂无微信用户数据' in wechat_page.text:
            print("✗ 仍然没有微信用户数据")
        elif '微信用户管理' in wechat_page.text and 'table' in wechat_page.text:
            print("✓ 有微信用户数据了")
            # 检查是否还有收集按钮
            if '收集微信用户' in wechat_page.text:
                print("收集按钮仍然存在")
            else:
                print("收集按钮已消失（正常）")
        
    except requests.exceptions.RequestException as e:
        print(f"请求失败: {e}")
    except Exception as e:
        print(f"其他错误: {e}")

if __name__ == '__main__':
    print("=== 测试收集功能POST请求 ===")
    test_collect_post()