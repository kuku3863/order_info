#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import re
from requests.sessions import Session

def test_admin_login():
    """测试管理员登录并访问微信用户页面"""
    session = Session()
    
    try:
        # 1. 获取登录页面和CSRF token
        login_page = session.get('http://127.0.0.1:5000/auth/login')
        print(f"登录页面状态码: {login_page.status_code}")
        
        if login_page.status_code != 200:
            print("无法访问登录页面")
            return
        
        # 使用正则表达式获取CSRF token
        csrf_token = None
        csrf_match = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', login_page.text)
        if csrf_match:
            csrf_token = csrf_match.group(1)
            print(f"找到CSRF token: {csrf_token[:20]}...")
        else:
            print("未找到CSRF token")
        
        # 2. 尝试登录管理员账户
        login_data = {
            'account': 'admin@example.com',
            'password': 'admin123',  # 假设密码
            'remember_me': False
        }
        
        if csrf_token:
            login_data['csrf_token'] = csrf_token
        
        login_response = session.post('http://127.0.0.1:5000/auth/login', data=login_data)
        print(f"登录响应状态码: {login_response.status_code}")
        
        if login_response.status_code == 302:
            print("登录成功，页面重定向")
        elif login_response.status_code == 200:
            if '无效的账号或密码' in login_response.text:
                print("登录失败：密码错误")
                return
            else:
                print("登录可能成功")
        
        # 3. 访问微信用户管理页面
        wechat_page = session.get('http://127.0.0.1:5000/admin/wechat-users')
        print(f"微信用户页面状态码: {wechat_page.status_code}")
        
        if wechat_page.status_code == 200:
            print("成功访问微信用户页面")
            
            # 检查关键内容
            keywords = ['微信用户管理', '收集微信用户', 'uncollected_count']
            for keyword in keywords:
                if keyword in wechat_page.text:
                    print(f"✓ 找到关键词: {keyword}")
                else:
                    print(f"✗ 未找到关键词: {keyword}")
            
            # 检查是否有收集按钮
            if '收集微信用户' in wechat_page.text and 'admin.collect_wechat_users' in wechat_page.text:
                print("✓ 收集按钮存在")
            else:
                print("✗ 收集按钮不存在")
                
        elif wechat_page.status_code == 302:
            print("页面重定向（可能需要重新登录）")
        elif wechat_page.status_code == 403:
            print("访问被拒绝（权限不足）")
        else:
            print(f"访问失败，状态码: {wechat_page.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"请求失败: {e}")

if __name__ == '__main__':
    print("=== 测试管理员登录和访问 ===")
    test_admin_login()