#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import WechatUser, Order

app = create_app('development')

with app.app_context():
    print("测试删除ID为3的张三用户...")
    
    # 获取用户
    user3 = WechatUser.query.filter_by(id=3).first()
    if not user3:
        print("用户3不存在")
        exit()
    
    print(f"用户详情: {user3.wechat_name}, 手机号: {user3.phone}, 微信号: {user3.wechat_id}")
    
    # 模拟删除逻辑
    related_orders = []
    if user3.phone:
        related_orders.extend(Order.query.filter_by(phone=user3.phone).all())
        print(f"通过手机号找到订单: {len(Order.query.filter_by(phone=user3.phone).all())}")
    else:
        print("手机号为空，跳过手机号查询")
        
    if user3.wechat_id:
        wechat_orders = Order.query.filter_by(wechat_id=user3.wechat_id).all()
        for order in wechat_orders:
            if order not in related_orders:
                related_orders.append(order)
        print(f"通过微信号找到订单: {len(wechat_orders)}")
    else:
        print("微信号为空，跳过微信号查询")
    
    orders_count = len(related_orders)
    print(f"总关联订单数: {orders_count}")
    
    if orders_count == 0:
        print("没有关联订单，可以直接删除")
        try:
            db.session.delete(user3)
            db.session.commit()
            print("用户删除成功！")
        except Exception as e:
            db.session.rollback()
            print(f"删除失败: {e}")
    else:
        print(f"有 {orders_count} 个关联订单，需要确认删除")