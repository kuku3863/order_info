#!/usr/bin/env python
from flask_migrate import current, heads
from app import create_app

app = create_app('default')
with app.app_context():
    current_rev = current()
    head_rev = heads()
    print(f"当前数据库版本: {current_rev}")
    print(f"最新迁移版本: {head_rev}")
    
    if current_rev == head_rev:
        print("数据库已是最新版本")
    else:
        print("数据库需要升级")