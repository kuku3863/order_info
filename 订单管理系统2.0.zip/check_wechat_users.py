#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import WechatUser, Order

app = create_app('development')

with app.app_context():
    print("微信用户列表:")
    users = WechatUser.query.all()
    for u in users:
        print(f"ID: {u.id}, 微信名: {u.wechat_name}, 微信号: {u.wechat_id}, 手机号: {u.phone}")
    
    print("\n检查张三用户:")
    zhangsan = WechatUser.query.filter_by(wechat_name='张三').first()
    if zhangsan:
        print(f"张三用户详情:")
        print(f"  ID: {zhangsan.id}")
        print(f"  微信名: {zhangsan.wechat_name}")
        print(f"  微信号: {zhangsan.wechat_id}")
        print(f"  手机号: {zhangsan.phone}")
        print(f"  邮箱: {zhangsan.email}")
        print(f"  地址: {zhangsan.address}")
        print(f"  创建时间: {zhangsan.create_time}")
        
        # 检查关联订单
        if zhangsan.phone:
            orders = Order.query.filter_by(phone=zhangsan.phone).all()
            print(f"  通过手机号关联的订单数量: {len(orders)}")
        else:
            print(f"  手机号为空，无法查找关联订单")
            
        if zhangsan.wechat_id:
            orders_by_wechat = Order.query.filter_by(wechat_id=zhangsan.wechat_id).all()
            print(f"  通过微信号关联的订单数量: {len(orders_by_wechat)}")
        else:
            print(f"  微信号为空，无法查找关联订单")
    else:
        print("未找到张三用户")
    
    print("\n检查所有微信用户的手机号和微信号情况:")
    empty_phone_users = WechatUser.query.filter(
        db.or_(WechatUser.phone.is_(None), WechatUser.phone == '')
    ).all()
    print(f"手机号为空的用户数量: {len(empty_phone_users)}")
    for user in empty_phone_users:
        print(f"  - {user.wechat_name} (ID: {user.id})")
    
    empty_wechat_id_users = WechatUser.query.filter(
        db.or_(WechatUser.wechat_id.is_(None), WechatUser.wechat_id == '')
    ).all()
    print(f"\n微信号为空的用户数量: {len(empty_wechat_id_users)}")
    for user in empty_wechat_id_users:
        print(f"  - {user.wechat_name} (ID: {user.id})")