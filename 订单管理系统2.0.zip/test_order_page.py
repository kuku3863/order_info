#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试订单列表页面渲染
"""

import requests
from bs4 import BeautifulSoup
import re

def test_order_page():
    """测试订单列表页面"""
    base_url = 'http://127.0.0.1:5000'
    
    # 创建会话
    session = requests.Session()
    
    print("开始测试订单列表页面...")
    
    # 1. 登录
    print("\n1. 登录管理员账户...")
    login_response = session.get(f'{base_url}/auth/login')
    if login_response.status_code != 200:
        print(f"✗ 无法访问登录页面: {login_response.status_code}")
        return
    
    # 提取CSRF token
    soup = BeautifulSoup(login_response.text, 'html.parser')
    csrf_token = None
    csrf_input = soup.find('input', {'name': 'csrf_token'})
    if csrf_input:
        csrf_token = csrf_input.get('value')
    
    login_data = {
        'account': 'admin',
        'password': 'admin123',
        'remember_me': False,
        'submit': 'Sign In'
    }
    
    if csrf_token:
        login_data['csrf_token'] = csrf_token
    
    login_response = session.post(f'{base_url}/auth/login', data=login_data)
    if login_response.status_code == 200 and 'login' not in login_response.url:
        print("✓ 登录成功")
    else:
        print(f"✗ 登录失败: {login_response.status_code}")
        return
    
    # 2. 访问订单列表页面
    print("\n2. 访问订单列表页面...")
    orders_response = session.get(f'{base_url}/orders')
    if orders_response.status_code != 200:
        print(f"✗ 无法访问订单列表页面: {orders_response.status_code}")
        return
    
    print(f"✓ 订单列表页面访问成功 (状态码: {orders_response.status_code})")
    
    # 3. 解析页面内容
    print("\n3. 分析页面内容...")
    soup = BeautifulSoup(orders_response.text, 'html.parser')
    
    # 检查表格是否存在
    table = soup.find('table')
    if table:
        print("✓ 找到表格元素")
        
        # 检查表头
        thead = table.find('thead')
        if thead:
            print("✓ 找到表头 (thead)")
            
            # 检查表头行
            header_rows = thead.find_all('tr')
            print(f"✓ 表头行数: {len(header_rows)}")
            
            # 检查表头单元格
            if header_rows:
                header_cells = header_rows[0].find_all('th')
                print(f"✓ 表头列数: {len(header_cells)}")
                
                # 显示表头内容
                print("\n表头内容:")
                for i, th in enumerate(header_cells[:5]):  # 只显示前5列
                    text = th.get_text(strip=True)
                    print(f"  列 {i+1}: {text}")
            else:
                print("✗ 未找到表头行")
        else:
            print("✗ 未找到表头 (thead)")
        
        # 检查表体
        tbody = table.find('tbody')
        if tbody:
            print("✓ 找到表体 (tbody)")
            
            # 检查数据行
            data_rows = tbody.find_all('tr')
            print(f"✓ 数据行数: {len(data_rows)}")
            
            if data_rows:
                # 检查第一行数据
                first_row = data_rows[0]
                cells = first_row.find_all('td')
                if cells:
                    print(f"✓ 第一行数据列数: {len(cells)}")
                    print("\n第一行数据内容:")
                    for i, td in enumerate(cells[:5]):  # 只显示前5列
                        text = td.get_text(strip=True)
                        print(f"  列 {i+1}: {text}")
                else:
                    # 检查是否是"暂无数据"行
                    text = first_row.get_text(strip=True)
                    if '暂无订单数据' in text:
                        print("! 显示'暂无订单数据'消息")
                    else:
                        print(f"? 第一行内容: {text}")
        else:
            print("✗ 未找到表体 (tbody)")
    else:
        print("✗ 未找到表格元素")
    
    # 4. 检查页面标题
    title = soup.find('title')
    if title:
        print(f"\n页面标题: {title.get_text(strip=True)}")
    
    # 5. 检查是否有错误信息
    error_messages = soup.find_all(class_=['alert-danger', 'text-danger', 'error'])
    if error_messages:
        print("\n发现错误信息:")
        for msg in error_messages:
            print(f"  - {msg.get_text(strip=True)}")
    
    # 6. 保存页面内容到文件以便调试
    with open('order_page_debug.html', 'w', encoding='utf-8') as f:
        f.write(orders_response.text)
    print("\n✓ 页面内容已保存到 order_page_debug.html")
    
    print("\n=== 测试完成 ===")

if __name__ == '__main__':
    test_order_page()