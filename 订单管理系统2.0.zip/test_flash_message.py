#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import re
from app import create_app, db
from app.models import WechatUser

def test_flash_message_behavior():
    """测试flash消息的显示和消失行为"""
    app = create_app('default')
    
    with app.app_context():
        # 先清理现有的微信用户，确保可以重新收集
        WechatUser.query.delete()
        db.session.commit()
        print("已清理现有微信用户")
    
    # 创建会话
    session = requests.Session()
    base_url = 'http://127.0.0.1:5000'
    
    try:
        # 1. 获取登录页面和CSRF token
        print("=== 获取登录页面 ===")
        login_page = session.get(f'{base_url}/auth/login')
        csrf_match = re.search(r'name="csrf_token" type="hidden" value="([^"]+)"', login_page.text)
        if not csrf_match:
            print("✗ 无法获取CSRF token")
            return
        csrf_token = csrf_match.group(1)
        print(f"✓ 获取到CSRF token: {csrf_token[:10]}...")
        
        # 2. 登录管理员账户
        print("\n=== 管理员登录 ===")
        login_data = {
            'csrf_token': csrf_token,
            'account': 'admin',
            'password': 'admin123',
            'remember_me': False
        }
        login_response = session.post(f'{base_url}/auth/login', data=login_data)
        print(f"登录状态码: {login_response.status_code}")
        
        # 3. 获取微信用户页面的CSRF token
        print("\n=== 获取微信用户页面 ===")
        wechat_page = session.get(f'{base_url}/admin/wechat-users')
        csrf_match = re.search(r'name="csrf_token" type="hidden" value="([^"]+)"', wechat_page.text)
        if csrf_match:
            csrf_token = csrf_match.group(1)
            print(f"✓ 获取到新的CSRF token: {csrf_token[:10]}...")
        
        # 4. 执行收集微信用户操作
        print("\n=== 执行收集微信用户操作 ===")
        collect_data = {
            'csrf_token': csrf_token
        }
        collect_response = session.post(f'{base_url}/admin/collect-wechat-users', data=collect_data)
        print(f"收集接口状态码: {collect_response.status_code}")
        
        # 5. 立即访问订单列表页面，检查是否有flash消息
        print("\n=== 访问订单列表页面 ===")
        orders_response = session.get(f'{base_url}/orders')
        print(f"订单页面状态码: {orders_response.status_code}")
        
        # 检查页面内容
        if 'alert' in orders_response.text:
            print("✓ 页面包含flash消息")
            if 'auto-dismiss' in orders_response.text:
                print("✓ flash消息包含auto-dismiss类")
            else:
                print("✗ flash消息缺少auto-dismiss类")
        else:
            print("✗ 页面不包含flash消息")
        
        # 检查是否有成功消息
        if '成功收集了' in orders_response.text:
            print("✓ 找到收集成功的消息")
        else:
            print("✗ 未找到收集成功的消息")
            
        print("\n=== 测试完成 ===")
        print("请在浏览器中访问 http://127.0.0.1:5000/orders 查看flash消息的行为")
        print("观察消息是否在5秒后平滑消失，不留空白区域")
        
    except Exception as e:
        print(f"✗ 测试过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_flash_message_behavior()