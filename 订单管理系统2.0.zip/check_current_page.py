#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
检查当前订单列表页面的实际状态
"""

import requests
from bs4 import BeautifulSoup
import re

def check_current_page():
    """检查当前页面状态"""
    base_url = 'http://127.0.0.1:5000'
    
    # 创建会话
    session = requests.Session()
    
    print("=== 检查当前订单列表页面状态 ===")
    
    # 1. 登录
    print("\n1. 登录管理员账户...")
    login_response = session.get(f'{base_url}/auth/login')
    if login_response.status_code != 200:
        print(f"✗ 无法访问登录页面: {login_response.status_code}")
        return
    
    # 提取CSRF token
    soup = BeautifulSoup(login_response.text, 'html.parser')
    csrf_token = None
    csrf_input = soup.find('input', {'name': 'csrf_token'})
    if csrf_input:
        csrf_token = csrf_input.get('value')
    
    login_data = {
        'account': 'admin',
        'password': 'admin123',
        'remember_me': False,
        'submit': 'Sign In'
    }
    
    if csrf_token:
        login_data['csrf_token'] = csrf_token
    
    login_response = session.post(f'{base_url}/auth/login', data=login_data)
    if login_response.status_code == 200 and 'login' not in login_response.url:
        print("✓ 登录成功")
    else:
        print(f"✗ 登录失败: {login_response.status_code}")
        return
    
    # 2. 访问订单列表页面
    print("\n2. 访问订单列表页面...")
    orders_response = session.get(f'{base_url}/orders')
    if orders_response.status_code != 200:
        print(f"✗ 无法访问订单列表页面: {orders_response.status_code}")
        return
    
    print(f"✓ 订单列表页面访问成功 (状态码: {orders_response.status_code})")
    
    # 3. 解析页面内容
    print("\n3. 详细分析页面内容...")
    soup = BeautifulSoup(orders_response.text, 'html.parser')
    
    # 检查统计信息
    stats_panel = soup.find('div', class_='panel-info')
    if stats_panel:
        stats_text = stats_panel.get_text()
        order_count_match = re.search(r'(\d+)\s*订单数量', stats_text)
        total_amount_match = re.search(r'￥([\d,\.]+)\s*总金额', stats_text)
        
        if order_count_match:
            print(f"✓ 统计显示订单数量: {order_count_match.group(1)}")
        if total_amount_match:
            print(f"✓ 统计显示总金额: ￥{total_amount_match.group(1)}")
    
    # 检查表格
    table = soup.find('table')
    if table:
        print("✓ 找到表格元素")
        
        # 检查表头
        thead = table.find('thead')
        if thead:
            header_cells = thead.find_all('th')
            print(f"✓ 表头列数: {len(header_cells)}")
            
            # 显示表头文本
            header_texts = []
            for th in header_cells:
                text = th.get_text(strip=True)
                if text and text not in ['', ' ']:
                    header_texts.append(text)
            print(f"✓ 表头内容: {', '.join(header_texts)}")
        
        # 检查表体数据
        tbody = table.find('tbody')
        if tbody:
            data_rows = tbody.find_all('tr')
            print(f"✓ 数据行数: {len(data_rows)}")
            
            if data_rows:
                print("\n前3行订单数据:")
                for i, row in enumerate(data_rows[:3]):
                    cells = row.find_all('td')
                    if len(cells) >= 5:
                        # 提取关键信息：订单编码、订单类型、微信名、微信号、手机号
                        order_code = cells[1].get_text(strip=True) if len(cells) > 1 else ''
                        order_type = cells[2].get_text(strip=True) if len(cells) > 2 else ''
                        wechat_name = cells[3].get_text(strip=True) if len(cells) > 3 else ''
                        wechat_id = cells[4].get_text(strip=True) if len(cells) > 4 else ''
                        phone = cells[5].get_text(strip=True) if len(cells) > 5 else ''
                        
                        print(f"  第{i+1}行: 编码={order_code}, 类型={order_type}, 微信名={wechat_name}, 微信号={wechat_id}, 手机={phone}")
                    else:
                        # 检查是否是"暂无数据"行
                        row_text = row.get_text(strip=True)
                        if '暂无订单数据' in row_text:
                            print(f"  第{i+1}行: {row_text}")
                        else:
                            print(f"  第{i+1}行: 列数不足 ({len(cells)} 列)")
            else:
                print("! 没有找到数据行")
        else:
            print("✗ 未找到表体 (tbody)")
    else:
        print("✗ 未找到表格元素")
    
    # 4. 检查JavaScript错误或CSS问题
    print("\n4. 检查可能的前端问题...")
    
    # 检查CSS文件是否正常加载
    css_response = session.get(f'{base_url}/static/styles.css')
    if css_response.status_code == 200:
        print("✓ CSS文件加载正常")
    else:
        print(f"✗ CSS文件加载失败: {css_response.status_code}")
    
    # 检查JS文件是否正常加载
    js_response = session.get(f'{base_url}/static/js/main.js')
    if js_response.status_code == 200:
        print("✓ JavaScript文件加载正常")
    else:
        print(f"✗ JavaScript文件加载失败: {js_response.status_code}")
    
    print("\n=== 建议解决方案 ===")
    print("如果页面显示仍有问题，请尝试以下操作：")
    print("1. 强制刷新浏览器缓存 (Ctrl+F5 或 Ctrl+Shift+R)")
    print("2. 清除浏览器缓存和Cookie")
    print("3. 尝试使用无痕/隐私模式打开页面")
    print("4. 检查浏览器控制台是否有JavaScript错误")
    print("5. 确认网络连接正常")
    
    print(f"\n当前访问地址: {base_url}/orders")
    print("如果问题仍然存在，请提供具体的错误描述或截图。")

if __name__ == '__main__':
    check_current_page()