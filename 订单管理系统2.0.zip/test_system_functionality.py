#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import sys
from datetime import datetime
from bs4 import BeautifulSoup
import re

def test_system():
    base_url = 'http://127.0.0.1:5000'
    session = requests.Session()
    
    print("=== 系统功能测试 ===")
    
    # 1. 测试登录
    print("\n1. 测试登录功能...")
    login_url = f"{base_url}/auth/login"
    
    # 获取登录页面
    response = session.get(login_url)
    if response.status_code != 200:
        print(f"❌ 无法访问登录页面: {response.status_code}")
        return False
    
    # 提取CSRF token
    soup = BeautifulSoup(response.text, 'html.parser')
    csrf_token = None
    csrf_input = soup.find('input', {'name': 'csrf_token'})
    if csrf_input:
        csrf_token = csrf_input.get('value')
    
    # 登录
    login_data = {
        'account': 'admin',  # 使用用户名而不是邮箱
        'password': 'admin123',
        'remember_me': False
    }
    
    if csrf_token:
        login_data['csrf_token'] = csrf_token
    
    response = session.post(login_url, data=login_data)
    if response.status_code == 200 and 'login' in response.url:
        print("❌ 登录失败")
        return False
    
    print("✅ 登录成功")
    
    # 2. 测试订单列表页面
    print("\n2. 测试订单列表页面...")
    orders_url = f"{base_url}/orders"
    response = session.get(orders_url)
    
    if response.status_code != 200:
        print(f"❌ 无法访问订单列表: {response.status_code}")
        return False
    
    print("✅ 订单列表页面访问成功")
    
    # 检查页面内容
    if '订单列表' in response.text:
        print("✅ 订单列表页面内容正常")
    else:
        print("⚠️ 订单列表页面内容可能有问题")
    
    # 3. 测试微信用户管理页面
    print("\n3. 测试微信用户管理页面...")
    wechat_users_url = f"{base_url}/admin/wechat-users"
    response = session.get(wechat_users_url)
    
    if response.status_code != 200:
        print(f"❌ 无法访问微信用户管理页面: {response.status_code}")
        return False
    
    print("✅ 微信用户管理页面访问成功")
    
    # 4. 测试创建订单页面
    print("\n4. 测试创建订单页面...")
    create_order_url = f"{base_url}/order/new"
    response = session.get(create_order_url)
    
    if response.status_code != 200:
        print(f"❌ 无法访问创建订单页面: {response.status_code}")
        return False
    
    print("✅ 创建订单页面访问成功")
    
    # 5. 测试导出功能
    print("\n5. 测试导出功能...")
    export_url = f"{base_url}/admin/wechat-users/export"
    export_data = {
        'format': 'excel',
        'order_type': '',
        'settlement_status': 'all',
        'start_date': '',
        'end_date': ''
    }
    
    response = session.post(export_url, data=export_data)
    
    if response.status_code == 200:
        print("✅ 导出功能正常")
        print(f"   导出文件大小: {len(response.content)} bytes")
    else:
        print(f"❌ 导出功能失败: {response.status_code}")
    
    print("\n=== 测试完成 ===")
    return True

if __name__ == '__main__':
    try:
        success = test_system()
        if success:
            print("\n🎉 系统功能测试通过！")
        else:
            print("\n❌ 系统功能测试失败！")
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ 测试过程中发生错误: {e}")
        sys.exit(1)