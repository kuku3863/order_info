#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import sys
from app import create_app, db
from app.models import Order, WechatUser

def test_collect_function():
    """测试收集微信用户功能"""
    app = create_app('default')
    
    with app.app_context():
        # 检查当前数据状态
        orders_with_phone = Order.query.filter(
            Order.phone.isnot(None),
            Order.phone != ''
        ).all()
        
        print(f"有手机号的订单数量: {len(orders_with_phone)}")
        
        # 按手机号分组
        phone_groups = {}
        for order in orders_with_phone:
            if order.phone not in phone_groups:
                phone_groups[order.phone] = []
            phone_groups[order.phone].append(order)
        
        print(f"唯一手机号数量: {len(phone_groups)}")
        
        # 检查现有微信用户
        existing_users = WechatUser.query.all()
        print(f"现有微信用户数量: {len(existing_users)}")
        
        # 计算可收集的用户数量
        uncollected_phones = []
        for phone in phone_groups.keys():
            existing_user = WechatUser.query.filter_by(phone=phone).first()
            if not existing_user:
                uncollected_phones.append(phone)
        
        print(f"可收集的微信用户数量: {len(uncollected_phones)}")
        print(f"可收集的手机号: {uncollected_phones}")
        
        return len(uncollected_phones)

def test_http_request():
    """测试HTTP请求收集功能"""
    try:
        # 测试GET请求到微信用户列表页面
        response = requests.get('http://127.0.0.1:5000/admin/wechat-users', timeout=5)
        print(f"GET请求状态码: {response.status_code}")
        
        if response.status_code == 200:
            print("微信用户列表页面可以正常访问")
            # 检查页面是否包含收集按钮
            if '收集微信用户' in response.text:
                print("页面包含收集按钮")
            else:
                print("页面不包含收集按钮")
        else:
            print(f"页面访问失败: {response.status_code}")
            
    except requests.exceptions.RequestException as e:
        print(f"HTTP请求失败: {e}")

if __name__ == '__main__':
    print("=== 测试收集微信用户功能 ===")
    
    # 测试数据库状态
    uncollected_count = test_collect_function()
    
    print("\n=== 测试HTTP访问 ===")
    # 测试HTTP请求
    test_http_request()
    
    print("\n=== 测试完成 ===")