#!/usr/bin/env python
# -*- coding: utf-8 -*-

from app import create_app, db
from app.models import Order, WechatUser
from datetime import datetime

def test_collect_function_direct():
    """直接测试收集函数逻辑"""
    app = create_app('default')
    
    with app.app_context():
        print("=== 收集前的状态 ===")
        orders_with_phone = Order.query.filter(
            Order.phone.isnot(None),
            Order.phone != ''
        ).all()
        print(f"有手机号的订单数量: {len(orders_with_phone)}")
        
        wechat_users = WechatUser.query.all()
        print(f"现有微信用户数量: {len(wechat_users)}")
        
        print("\n=== 执行收集逻辑 ===")
        try:
            # 复制collect_wechat_users函数的逻辑
            phone_groups = {}
            for order in orders_with_phone:
                if order.phone not in phone_groups:
                    phone_groups[order.phone] = []
                phone_groups[order.phone].append(order)
            
            print(f"手机号分组: {list(phone_groups.keys())}")
            
            collected_count = 0
            updated_count = 0
            
            for phone, orders in phone_groups.items():
                print(f"\n处理手机号: {phone}")
                
                # 根据手机号查找现有用户
                existing_user = WechatUser.query.filter_by(phone=phone).first()
                print(f"现有用户: {existing_user}")
                
                # 从该手机号的所有订单中选择最新的信息
                latest_order = max(orders, key=lambda x: x.create_time)
                print(f"最新订单: {latest_order.order_code}, 微信名: {latest_order.wechat_name}")
                
                # 选择最好的微信名
                best_wechat_name = None
                for order in orders:
                    if order.wechat_name and not order.wechat_name.startswith('用户_'):
                        best_wechat_name = order.wechat_name
                        break
                if not best_wechat_name:
                    best_wechat_name = latest_order.wechat_name or f'用户_{phone}'
                print(f"最佳微信名: {best_wechat_name}")
                
                # 选择最好的微信号
                best_wechat_id = None
                for order in orders:
                    if order.wechat_id and order.wechat_id.strip():
                        best_wechat_id = order.wechat_id
                        break
                print(f"最佳微信号: {best_wechat_id}")
                
                if not existing_user:
                    # 创建新的微信用户
                    print("创建新用户...")
                    wechat_user = WechatUser(
                        wechat_name=best_wechat_name,
                        wechat_id=best_wechat_id,
                        phone=phone,
                        create_time=datetime.utcnow(),
                        update_time=datetime.utcnow()
                    )
                    db.session.add(wechat_user)
                    collected_count += 1
                    print(f"✓ 创建用户: {wechat_user.wechat_name}")
                else:
                    print("用户已存在，跳过")
            
            # 提交数据库更改
            print(f"\n提交数据库更改...")
            db.session.commit()
            print(f"✓ 成功收集了 {collected_count} 个新微信用户")
            
        except Exception as e:
            print(f"✗ 收集过程中出错: {str(e)}")
            db.session.rollback()
            import traceback
            traceback.print_exc()
        
        print("\n=== 收集后的状态 ===")
        wechat_users_after = WechatUser.query.all()
        print(f"微信用户数量: {len(wechat_users_after)}")
        for user in wechat_users_after:
            print(f"  - {user.wechat_name}, 手机号: {user.phone}, 微信号: {user.wechat_id}")

if __name__ == '__main__':
    test_collect_function_direct()