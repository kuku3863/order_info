#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试微信用户统计导出功能
"""

import requests
import time
from datetime import datetime, timedelta

def test_export_function():
    """测试统计导出功能"""
    base_url = 'http://127.0.0.1:5000'
    
    # 创建会话
    session = requests.Session()
    
    print("开始测试微信用户统计导出功能...")
    
    # 1. 登录管理员账户
    print("\n1. 登录管理员账户...")
    login_data = {
        'username': 'admin',
        'password': 'admin123',
        'submit': 'Sign In'
    }
    
    response = session.post(f'{base_url}/auth/login', data=login_data)
    if response.status_code == 200:
        print("✓ 管理员登录成功")
    else:
        print(f"✗ 管理员登录失败: {response.status_code}")
        return
    
    # 2. 访问微信用户列表页面
    print("\n2. 访问微信用户列表页面...")
    response = session.get(f'{base_url}/admin/wechat-users')
    if response.status_code == 200:
        print("✓ 微信用户列表页面访问成功")
        # 检查是否包含统计导出按钮
        if '统计导出' in response.text:
            print("✓ 发现统计导出按钮")
        else:
            print("✗ 未发现统计导出按钮")
    else:
        print(f"✗ 微信用户列表页面访问失败: {response.status_code}")
        return
    
    # 3. 访问统计导出页面
    print("\n3. 访问统计导出页面...")
    response = session.get(f'{base_url}/admin/wechat-users/export')
    if response.status_code == 200:
        print("✓ 统计导出页面访问成功")
        # 检查页面内容
        if '导出设置' in response.text and '开始日期' in response.text:
            print("✓ 导出表单显示正常")
        else:
            print("✗ 导出表单显示异常")
    else:
        print(f"✗ 统计导出页面访问失败: {response.status_code}")
        return
    
    # 4. 测试导出功能（Excel格式）
    print("\n4. 测试Excel导出功能...")
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)  # 最近30天
    
    export_data = {
        'start_date': start_date.strftime('%Y-%m-%d'),
        'end_date': end_date.strftime('%Y-%m-%d'),
        'order_type': '',  # 所有订单类型
        'export_format': 'excel',
        'include_details': 'y',
        'submit': '导出数据'
    }
    
    response = session.post(f'{base_url}/admin/wechat-users/export', data=export_data)
    if response.status_code == 200:
        content_type = response.headers.get('Content-Type', '')
        if 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' in content_type:
            print("✓ Excel文件导出成功")
            print(f"  文件大小: {len(response.content)} 字节")
        else:
            print(f"✗ Excel导出失败，返回内容类型: {content_type}")
    else:
        print(f"✗ Excel导出请求失败: {response.status_code}")
    
    # 5. 测试导出功能（CSV格式）
    print("\n5. 测试CSV导出功能...")
    export_data['export_format'] = 'csv'
    
    response = session.post(f'{base_url}/admin/wechat-users/export', data=export_data)
    if response.status_code == 200:
        content_type = response.headers.get('Content-Type', '')
        if 'text/csv' in content_type:
            print("✓ CSV文件导出成功")
            print(f"  文件大小: {len(response.content)} 字节")
            # 显示CSV内容的前几行
            csv_content = response.content.decode('utf-8-sig')
            lines = csv_content.split('\n')[:5]
            print("  CSV内容预览:")
            for line in lines:
                if line.strip():
                    print(f"    {line}")
        else:
            print(f"✗ CSV导出失败，返回内容类型: {content_type}")
    else:
        print(f"✗ CSV导出请求失败: {response.status_code}")
    
    print("\n测试完成！")
    print("\n功能说明:")
    print("- 统计导出功能已成功集成到微信用户列表页面")
    print("- 支持按日期范围和订单类型筛选数据")
    print("- 支持Excel和CSV两种导出格式")
    print("- 可选择是否包含订单详情")
    print("- 适用于工资结算等业务场景")
    print("\n请在浏览器中访问 http://127.0.0.1:5000/admin/wechat-users 查看统计导出按钮")

if __name__ == '__main__':
    test_export_function()